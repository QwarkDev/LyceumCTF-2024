<?php 
  if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if($username == 'qookie' && $password == 'PolyCTF') {
      echo "PolyCTF{C1!eNT_51dE_lo9!N}";
      exit;
    } else {
      $err = 'Invalid username or password';
    }
  }
?>

<html>
  <head>
    <link rel="stylesheet" href="main.css">
    <title>Login</title>
  </head>
  <body>
    <div class="login">
      <h1>Login</h1>
      <form method="post">
        <input type="text" name="username" placeholder="Username" required="required" />
        <input type="password" name="password" placeholder="Password" required="required" />
        <button type="submit">Login</button>
        <?php if (isset($err)) echo "<h4>$err</h4>"; ?>
      </form>
    </div>
  </body>
</html>































































  <!-- 
    credits
      username: qookie
      password: PolyCTF 
  -->