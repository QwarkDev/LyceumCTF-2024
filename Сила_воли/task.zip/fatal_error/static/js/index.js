let clicks = 0;
function onClick() {
  clicks += 1;
  if (clicks < 6000) {
    document.getElementById("clicks").innerHTML = clicks;
  }

  let url = 'http://127.0.0.1:1636/check_clicks';
  fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({clicks: clicks}),
  }).then(response => response.json()).then(data => {
    if(data != 'err') {
      document.getElementById("flag").innerHTML = data;
    }
  })
};