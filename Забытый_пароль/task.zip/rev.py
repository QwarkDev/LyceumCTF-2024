from math import *

flag = b'(GDQ\x1b,\x1eS@LLHK\x12\x07\x07OOO\x06QGMLM:=\x06;GE\x07O9L;@\x17N\x15!P\x1d\x0c)A\x1e\x10(<OU'
print('[*] Hello this is simple cipher program. Enter the message: ')
message = str(input())
if message == "Give me flag":
    print("[*] where 'please'?")
elif message == "Give me flag please":
    print("[*] None. GLHF")

key = ord(message[len(message)-1])
list_output = []
flag_ouput = []
for i in range(0, len(message)):
    list_output.append(chr(ord(message[i])+key))
for i in range(0, len(flag)):
        flag_ouput.append(chr(flag[i]+key))

str_ouput = ''.join(list_output)
str_flag = ''.join(flag_ouput)

print('[*] This is your cipher text: ', str_ouput.encode())
print('[*] This is flag output: ', str_flag.encode())