from math import *

flag = b'`\x17^\x18s,t\x1aX\x0cF\x11CB\x1dNG\x0fEOI\x17G\x15E\x1aWOS\x17_NG\x19F\x02XGD\\tM}QF\tS\x15@ U\x1c'
print('[*] Hello this is simple cipher program. Enter the message: ')
message = str(input())
if message == "Give me flag":
    print("[*] where 'please'?")
elif message == "Give me flag please":
    print("[*] None. GLHF")
key = '0x2a'
list_output = []
for i in range(0, len(message)):
    list_output.append(chr(ord(message[i])^ord(key[i % len(key)])))

str_ouput = ''.join(list_output)

print('[*] This is your cipher text: ', str_ouput.encode())
print('[*] This is flag output: ', flag)