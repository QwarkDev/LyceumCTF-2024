<?php 
  if($_SERVER['REQUEST_METHOD'] == 'POST') {
    echo "PolyCTF{g3n1us_1n_w3b}";
  }
?>

<html>
  <head>
    <link rel="stylesheet" href="main.css">
    <title>Login</title>
  </head>
  <body>
    <div class="login">
      <form method="post">
        <input disabled type="text" name="username" placeholder="Username" required="required" />
        <button disabled type="submit">Login</button>
        <?php if (isset($err)) echo "<h4>$err</h4>"; ?>
      </form>
    </div>
  </body>
</html>
